#include "BoardGame.h"

bool
BoardGame::reset()
{
  return true;
}


BoardGame::~BoardGame()
{
}
